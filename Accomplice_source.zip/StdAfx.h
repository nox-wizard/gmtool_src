#if !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

#pragma once
#pragma pack(1)

#define WIN32_LEAN_AND_MEAN
#define VC_EXTRALEAN

#include <AfxWin.h>
#include <AfxCmn.h>

#include <vector>
#include <fstream>
#include <strstream>
using namespace std;

//{{AFX_INSERT_LOCATION}}


#endif // !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
