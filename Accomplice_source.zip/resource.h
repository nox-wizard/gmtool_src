//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Accomplice.rc
//
#define IDB_LOGO                        101
#define IDD_SPLASH                      102
#define IDD_ACCOMPLICE                  103
#define IDI_ACCOMPLICE                  104
#define IDD_PROMPT                      105
#define IDD_OPTIONS                     106
#define IDD_GENERIC                     107
#define IDD_ACCOMP_H                    108
#define IDC_OPTIONS                     990
#define IDC_INFO                        991
#define IDC_INF1                        992
#define IDC_INF2                        993
#define IDC_INF3                        994
#define IDC_INFO2                       995
#define IDC_RELOAD                      996
#define IDC_SCPINFO                     997
#define IDC_TAB                         1001
#define IDC_BUTTON1                     1003
#define IDC_PROMPT                      1006
#define IDC_EDIT1                       1007
#define IDC_EDIT2                       1008
#define IDC_EDIT3                       1009
#define IDC_EDIT4                       1010
#define IDC_EDIT5                       1011
#define IDC_EDIT6                       1012
#define IDC_EDIT7                       1013
#define IDC_EDIT8                       1014
#define IDC_STRING                      1015
#define IDC_TOP                         1016
#define IDC_PREFIX                      1017
#define IDC_LINK                        1018
#define IDC_HEX                         1019
#define IDC_CHECK1                      1020
#define IDC_SYSTRAY                     1020
#define IDC_SCPLST                      1021
#define IDC_PROGRESS                    1028
#define IDC_LOGO                        1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
