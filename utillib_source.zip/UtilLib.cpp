/*
Accomplice GM Tool Version 2.XX - GM Tool for Ultima Online Emulators.
Copyright (C) 2001 Bryan "Zippy" Pass
	E-Mail: zippy@uoxdev.com or "Zippy-" on irc.stratics.com #uox
		Contact me electronicly reguarding written contact.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by 
the Free Software Foundation; either version 2 of the License, or (at 
your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program; if not, write to:
Free Software Foundation, Inc., 
59 Temple Place, Suite 330
Boston, MA 02111-1307 USA
*/

#include "stdafx.h"
#include "..\UtilLib.h"
#include <stdio.h>

HINSTANCE hInst = NULL;
#pragma data_seg("Shared")
	HWND hPostWnd = NULL;
	HWND hWatchWnd = NULL;
	HHOOK hWatchHook = NULL;
	UINT nActivateMsg = WM_USER;
	UINT nFocusMsg = WM_USER+1;
#pragma data_seg()

bool CheckParent( HWND hCheck, HWND hComp )
{
	HWND hParent = GetParent( hCheck );
	HWND hDesktop = GetDesktopWindow();

	while ( hParent != hComp && hParent != NULL && hParent != hDesktop )
	{
		hParent = GetParent( hParent );
	}

	return ( hParent == hComp );
}

LRESULT CALLBACK WatchHookProc( int nCode, WPARAM wParam, LPARAM lParam )
{
	CWPRETSTRUCT *msg = (CWPRETSTRUCT *)lParam;
	HWND Fore;

	if ( !hWatchWnd || !IsWindow(hWatchWnd) )
		hWatchWnd = FindUOWindow();

	if ( msg->hwnd == hWatchWnd )
	{
		switch ( msg->message )
		{
		case WM_ACTIVATE:
			SendMessage( hPostWnd, nActivateMsg, msg->wParam, msg->lParam );
			break;

		case WM_KILLFOCUS:
			Fore = GetForegroundWindow();
			if ( ((HWND)(msg->wParam)) != hPostWnd && Fore != hPostWnd && !CheckParent(Fore,hPostWnd) )
				PostMessage( hPostWnd, nFocusMsg, FALSE, msg->wParam );
			break;

		case WM_SETFOCUS:
			SendMessage( hPostWnd, nFocusMsg, TRUE, 0 );
			break;

		}
	}/* else if ( msg->hwnd == hPostWnd && msg->message == WM_KILLFOCUS )
	{
		Fore = GetForegroundWindow();
		if ( ((HWND)(msg->wParam)) != hWatchWnd && Fore != hWatchWnd && !CheckParent(Fore,hWatchWnd) )
			PostMessage( hPostWnd, nFocusMsg, FALSE, msg->wParam );
	}*/

	return CallNextHookEx( hWatchHook, nCode, wParam, lParam );
}

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  dwReason, LPVOID lpReserved )
{
	hInst = (HINSTANCE)hModule;
    return TRUE;
}

bool UTILAPI InstallMaxMinHook( HWND hNotify, HWND hWatch, UINT Activate, UINT Focus )
{
	if ( !hWatchHook )
		hWatchHook = SetWindowsHookEx( WH_CALLWNDPROCRET, WatchHookProc, hInst, NULL );
	
	hPostWnd = hNotify;
	hWatchWnd = hWatch;
	nActivateMsg = Activate;
	nFocusMsg = Focus;

	return true;
}

bool UTILAPI RemoveMaxMinHook( void )
{
	if ( hWatchHook )
	{
		UnhookWindowsHookEx( hWatchHook );
		hWatchHook = NULL;
		return true;
	} else 
		return false;
}

HWND UTILAPI FindUOWindow( void )
{
	HWND hWnd;

	hWnd = FindWindow( "Ultima Online", NULL );
	if ( !hWnd )
		hWnd = FindWindow( "Ultima Online Third Dawn", NULL );

	return hWnd;
}
